package ps3_1Assignment3;

public abstract class Instrument {
	public abstract void play();
}
